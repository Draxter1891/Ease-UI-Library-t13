export declare const focusAnimations: {
    glow: (el: HTMLElement) => void;
    reset: (el: HTMLElement) => void;
};
