import { jsx as a, jsxs as h } from "react/jsx-runtime";
import { Slot as M } from "@radix-ui/react-slot";
import v, { useRef as C, useEffect as q } from "react";
import { cva as N } from "class-variance-authority";
import E from "clsx";
import { twMerge as L } from "tailwind-merge";
import t from "gsap";
function b(...e) {
  return L(E(e));
}
const V = {
  fadeIn: (e) => t.fromTo(e, { opacity: 0 }, { opacity: 1, duration: 0.8 }),
  scaleIn: (e) => t.fromTo(
    e,
    { scale: 0 },
    { scale: 1, duration: 0.6, ease: "back.out(1.7)" }
  ),
  slideUp: (e) => t.fromTo(e, { y: 50, opacity: 0 }, { y: 0, opacity: 1, duration: 0.6 }),
  bounceIn: (e) => t.fromTo(
    e,
    { scale: 0 },
    { scale: 1, duration: 0.8, ease: "bounce.out" }
  ),
  none: () => {
  }
}, k = {
  jiggle: (e) => {
    t.killTweensOf(e), t.to(e, {
      keyframes: [
        { scale: 1.1, rotation: 2, duration: 0.15, ease: "power1.out" },
        { scale: 0.95, rotation: -2, duration: 0.15, ease: "power1.inOut" },
        { scale: 1.05, rotation: 1, duration: 0.15, ease: "power1.out" },
        { scale: 1, rotation: 0, duration: 0.2, ease: "back.out(2)" }
      ]
    });
  },
  scale: (e) => {
    t.to(e, { scale: 1.05, duration: 0.2, ease: "power1.out" });
  },
  bounce: (e) => {
    t.to(e, {
      y: -5,
      duration: 0.3,
      ease: "bounce.out",
      yoyo: !0,
      repeat: 1
    });
  },
  shadowPulse: (e) => {
    t.fromTo(
      e,
      { boxShadow: "0px 0px 0px rgba(0,0,0,0)" },
      {
        boxShadow: "0px 10px 25px rgba(0,0,0,0.2)",
        duration: 0.4,
        ease: "power2.inOut"
      }
    );
  },
  float3D: (e) => {
    const o = e.querySelector("img"), r = e.querySelector("h3"), s = e.querySelector("p"), n = e.querySelector("div:last-child");
    t.to(e, {
      // y: -10,
      scale: 1.03,
      rotateX: 5,
      rotateY: 2,
      transformPerspective: 700,
      duration: 0.1,
      ease: "power3.out"
    }), t.to(o, { y: -10, scale: 1.05, duration: 0.5, ease: "power3.out" }), t.to(r, { y: -8, duration: 0.4, ease: "power3.out" }), t.to(s, { y: -6, duration: 0.4, ease: "power3.out" }), t.to(n, { y: -5, opacity: 1, duration: 0.4, ease: "power3.out" });
  },
  reset: (e) => {
    const o = e.querySelector("img"), r = e.querySelector("h3"), s = e.querySelector("p"), n = e.querySelector("div:last-child");
    t.to(e, {
      y: 0,
      rotateX: 0,
      rotateY: 0,
      scale: 1,
      duration: 0.1,
      ease: "power3.inOut"
    }), t.to([o, r, s, n], {
      y: 0,
      scale: 1,
      opacity: 1,
      duration: 0.4,
      ease: "power3.inOut"
    });
  },
  wobbleFollow: (e) => {
    const o = e.getBoundingClientRect(), r = (n) => {
      const g = n.clientX - o.left, c = n.clientY - o.top, d = o.width / 2, p = o.height / 2, i = (c - p) / p * 5, m = (g - d) / d * 5;
      t.to(e, {
        rotationX: i,
        rotationY: m,
        transformPerspective: 800,
        transformOrigin: "center",
        ease: "power2.out",
        duration: 0.01
      });
    }, s = () => {
      t.to(e, {
        rotationX: 0,
        rotationY: 0,
        duration: 0.3,
        ease: "elastic.out(1, 0.3)"
      });
    };
    return e.addEventListener("mousemove", r), e.addEventListener("mouseleave", s), () => {
      e.removeEventListener("mousemove", r), e.removeEventListener("mouseleave", s);
    };
  },
  none: () => {
  }
}, O = N(
  "inline-flex items-center cursor-pointer justify-center rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50",
  {
    variants: {
      variant: {
        dark: "bg-slate-900 text-white",
        primary: "bg-indigo-600 hover:bg-indigo-700 text-white",
        secondary: "bg-indigo-500 hover:bg-indigo-700 text-white",
        destructive: "bg-red-700 text-white hover:bg-red-900",
        ok: "bg-green-500 hover:bg-green-700",
        ghost: "bg-gray-50 hover:bg-gray-100 text-gray-700",
        link: "bg-transparent hover:bg-transparent text-indigo-600",
        outline: "bg-transparent hover:bg-gray-100 text-gray-700 border border-gray-300"
      },
      size: {
        default: "px-9 py-3",
        sm: "px-4 py-2",
        lg: "px-14 py-4",
        xl: "px-16 py-4",
        icon: "w-12 h-12",
        full: "w-full h-12",
        auto: "w-auto h-auto"
      }
    },
    defaultVariants: {
      variant: "primary",
      size: "default"
    }
  }
), T = v.forwardRef(
  ({
    className: e,
    variant: o,
    size: r,
    asChild: s = !1,
    animation: n = "fadeIn",
    hoverAnimation: g = "jiggle",
    ...c
  }, d) => {
    const p = s ? M : "button", i = C(null);
    q(() => {
      const u = i.current;
      !u || n === "none" || V[n]?.(u);
    }, [n]);
    const m = () => {
      const u = i.current;
      u && k[g]?.(u);
    }, x = () => {
      t.to(i.current, {
        scale: 1,
        rotation: 0,
        y: 0,
        duration: 0.3
      });
    }, y = () => {
      t.to(i.current, { scale: 0.92, duration: 0.1 });
    }, f = () => {
      t.to(i.current, {
        scale: 1.05,
        duration: 0.15,
        ease: "back.out(2)"
      });
    };
    return /* @__PURE__ */ a(
      p,
      {
        ref: (u) => {
          i.current = u, typeof d == "function" ? d(u) : d && (d.current = u);
        },
        className: b(O({ variant: o, size: r, className: e })),
        onMouseEnter: m,
        onMouseLeave: x,
        onMouseDown: y,
        onMouseUp: f,
        ...c
      }
    );
  }
);
T.displayName = "Button";
const X = N(
  "rounded-lg transition-all duration-300 cursor-pointer overflow-hidden",
  {
    variants: {
      variant: {
        light: "bg-white text-gray-800 shadow-lg hover:shadow-xl",
        dark: "bg-slate-800 text-white shadow-md hover:shadow-lg",
        outline: "border border-gray-300 bg-transparent text-gray-800 dark:border-gray-700"
      },
      // hoverEffect: {
      //   none: "",
      //   scale: "hover:scale-[1.02]",
      //   shadow: "hover:shadow-xl",
      //   lift: "hover:-translate-y-1 hover:shadow-xl",
      //   rotate: "hover:rotate-1",
      // },
      size: {
        sm: "p-3 text-sm",
        md: "p-6 text-base",
        lg: "p-8 text-lg"
      }
    },
    defaultVariants: {
      variant: "light",
      size: "md"
    }
  }
), Y = v.forwardRef(
  ({
    asChild: e = !1,
    title: o,
    description: r,
    children: s,
    className: n,
    variant: g,
    image: c,
    ratio: d = "16:9",
    size: p,
    footer: i,
    animate: m = !0,
    hoverAnimation: x = "none",
    ...y
  }, f) => {
    const u = e ? M : "div", w = C(null), S = () => {
      const l = w.current;
      l && k[x]?.(l);
    }, z = () => {
      const l = w.current;
      l && k.reset(l);
    }, I = () => {
      const l = w.current;
      l && t.to(l, { scale: 0.95, duration: 0.1, ease: "power1.inOut" });
    }, R = () => {
      const l = w.current;
      l && t.to(l, { scale: 1.05, duration: 0.1, ease: "back.out(2)" });
    }, j = d === "16:9" ? "aspect-video" : d === "4:3" ? "aspect-[4/3]" : "aspect-square";
    return /* @__PURE__ */ h(
      u,
      {
        ref: (l) => {
          w.current = l, typeof f == "function" ? f(l) : f && (f.current = l);
        },
        onMouseEnter: S,
        onMouseLeave: z,
        onMouseDown: I,
        onMouseUp: R,
        className: b(X({ variant: g, size: p }), n),
        role: "article",
        tabIndex: 0,
        ...y,
        children: [
          c && /* @__PURE__ */ a("div", { className: `${j} mb-4`, children: /* @__PURE__ */ a(
            "img",
            {
              src: c,
              alt: o || "Card image",
              className: "w-full h-full object-cover rounded-md"
            }
          ) }),
          o && /* @__PURE__ */ a("h3", { className: "font-semibold text-lg mb-2 text-[inherit]", children: o }),
          r && /* @__PURE__ */ a("p", { className: "text-gray-500 mb-4 text-[inherit]", children: r }),
          s,
          i && /* @__PURE__ */ a("div", { className: "mt-4", children: i })
        ]
      }
    );
  }
);
Y.displayName = "Card";
const D = N(
  "fixed inset-0 flex items-center justify-center z-50 transition-all duration-300",
  {
    variants: {
      variant: {
        light: "bg-white text-gray-900 shadow-2xl border border-gray-200 hover:shadow-xl",
        dark: "bg-slate-900 text-white shadow-lg border border-slate-700 hover:shadow-xl",
        outline: "bg-transparent border border-gray-400 text-gray-800 dark:border-gray-600 dark:text-gray-100 backdrop-blur-md"
      },
      size: {
        sm: "w-[90%] max-w-sm p-4",
        md: "w-[90%] max-w-md p-6",
        lg: "w-[90%] max-w-lg p-8"
      }
    },
    defaultVariants: {
      variant: "light",
      size: "md"
    }
  }
), U = v.forwardRef(
  ({
    asChild: e = !1,
    title: o,
    description: r,
    children: s,
    className: n,
    isOpen: g = !1,
    onClose: c,
    onDone: d,
    doneText: p = "Done",
    closeText: i = "Close",
    variant: m,
    size: x,
    ...y
  }, f) => g ? /* @__PURE__ */ h("div", { className: "fixed inset-0 flex items-center justify-center z-50", children: [
    /* @__PURE__ */ a(
      "div",
      {
        className: "fixed inset-0 bg-black/50 backdrop-blur-sm transition-opacity duration-300",
        onClick: c
      }
    ),
    /* @__PURE__ */ a(
      e ? M : "div",
      {
        ref: f,
        className: b(
          D({ variant: m, size: x }),
          "relative rounded-xl transform scale-100 transition-all duration-300 animate-fadeIn",
          n
        ),
        ...y,
        children: /* @__PURE__ */ h("div", { children: [
          o && /* @__PURE__ */ a("h3", { className: "text-xl font-semibold mb-2 text-[inherit]", children: o }),
          r && /* @__PURE__ */ a("p", { className: "text-gray-600 dark:text-gray-300 mb-4 text-[inherit]", children: r }),
          /* @__PURE__ */ a("div", { className: "mb-4", children: s }),
          /* @__PURE__ */ h("div", { className: "flex justify-end gap-3 mt-6", children: [
            /* @__PURE__ */ a(
              "button",
              {
                onClick: c,
                className: b(
                  "px-4 py-2 rounded-md font-medium transition",
                  m === "dark" ? "border border-slate-600 hover:bg-slate-700" : "border border-gray-300 hover:bg-gray-100"
                ),
                children: i
              }
            ),
            /* @__PURE__ */ a(
              "button",
              {
                onClick: d,
                className: b(
                  "px-4 py-2 rounded-md text-white font-medium transition",
                  m === "dark" ? "bg-indigo-500 hover:bg-indigo-600" : "bg-indigo-600 hover:bg-indigo-700"
                ),
                children: p
              }
            )
          ] })
        ] })
      }
    )
  ] }) : null
);
U.displayName = "Modal";
const B = N(
  "w-full rounded-md focus:outline-none shadow-sm transition-all duration-150 bg-white placeholder:text-gray-400",
  // w-full bg-transparent border-b border-gray-500 pb-2 pt-6 focus:outline-none transition-all
  {
    variants: {
      size: {
        sm: "px-3 py-1.5 text-sm",
        md: "px-4 py-2 text-base",
        lg: "px-5 py-3 text-lg"
      },
      tone: {
        default: "border-gray-300 focus:ring-2 focus:ring-blue-400 focus:border-blue-400",
        error: "border-red-400 focus:ring-2 focus:ring-red-400 focus:border-red-400",
        success: "border-green-400 focus:ring-2 focus:ring-green-400 focus:border-green-400"
      },
      disabled: {
        true: "bg-gray-100 text-gray-400 cursor-not-allowed opacity-80"
      }
    },
    defaultVariants: {
      size: "md",
      tone: "default",
      disabled: !1
    }
  }
), P = v.forwardRef(
  ({
    label: e,
    hint: o,
    error: r,
    className: s,
    size: n = "md",
    tone: g,
    disabled: c,
    id: d,
    ...p
  }, i) => {
    const m = d || v.useId?.() || `input-${Math.random().toString(36).slice(2, 9)}`;
    return /* @__PURE__ */ h("div", { className: "flex flex-col gap-1 w-full", children: [
      e && /* @__PURE__ */ a(
        "label",
        {
          htmlFor: m,
          className: "text-sm font-medium text-gray-700",
          children: e
        }
      ),
      /* @__PURE__ */ a(
        "input",
        {
          id: m,
          ref: i,
          className: b(B({ size: n, tone: g, disabled: c }), s),
          disabled: c ?? !1,
          ...p
        }
      ),
      r ? /* @__PURE__ */ a("p", { className: "text-sm text-red-500", children: r }) : o ? /* @__PURE__ */ a("p", { className: "text-sm text-gray-500", children: o }) : null
    ] });
  }
);
P.displayName = "Input";
const A = {
  top: "bottom-full left-1/2 mb-2 -translate-x-1/2",
  right: "left-full top-1/2 ml-2 -translate-y-1/2",
  bottom: "left-1/2 top-full mt-2 -translate-x-1/2",
  left: "right-full top-1/2 mr-2 -translate-y-1/2"
}, W = ({
  content: e,
  children: o,
  position: r = "top",
  variant: s = "dark",
  className: n
}) => /* @__PURE__ */ h("span", { className: "group relative inline-flex", children: [
  /* @__PURE__ */ a("span", { tabIndex: 0, className: "inline-flex cursor-help focus:outline-none", children: o }),
  /* @__PURE__ */ a(
    "span",
    {
      role: "tooltip",
      className: b(
        "pointer-events-none absolute z-10 w-max max-w-56 rounded-md px-3 py-2 text-sm opacity-0 shadow-lg transition-opacity duration-200 group-hover:opacity-100 group-focus-within:opacity-100",
        A[r],
        s === "light" ? "border border-gray-200 bg-white text-gray-900" : "bg-gray-900 text-white",
        n
      ),
      children: e
    }
  )
] });
export {
  T as Button,
  Y as Card,
  P as Input,
  U as Modal,
  W as Tooltip,
  O as buttonVariants,
  X as cardVariants,
  B as inputVariants,
  D as modalVariants
};
