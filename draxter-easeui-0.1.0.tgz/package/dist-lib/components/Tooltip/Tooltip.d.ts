import React from "react";
type TooltipProps = {
    content: React.ReactNode;
    children: React.ReactNode;
    position?: "top" | "right" | "bottom" | "left";
    variant?: "dark" | "light";
    className?: string;
};
declare const Tooltip: ({ content, children, position, variant, className, }: TooltipProps) => import("react/jsx-runtime").JSX.Element;
export { Tooltip };
